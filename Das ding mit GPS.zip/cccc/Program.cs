﻿using System; // ohne geht ja schlecht

class Program // wad auch immer das nochmal macht
{
    static void Main() // ab hier ist die ganze sache für'n Void
    {
        Console.WriteLine("Geben Sie die Dezimalminute ein:"); // und das war keine bitte
        string input = Console.ReadLine(); // ich hoffe die konsole ist nicht dyslexic

        if (double.TryParse(input, out double decimalMinute)) // nichtmal gott weiß warum ich das mach
        {
            double dezimalgrad = Math.Truncate(decimalMinute); // Ganzzahlanteil
            double dezimalminuten = decimalMinute - dezimalgrad; // Wert nach dem Komma

            double dezimalsekunden = dezimalminuten * 60.0; // Umrechnung in Sekunden

            Console.WriteLine($"Der Sekundenwert beträgt: {dezimalsekunden} Sekunden"); // herzlichen glühstrumpf du hast eine zahl
        }
        else // das erste mal das was nach dem sonst passiert
        {
            Console.WriteLine("Ungültige Eingabe. Bitte geben Sie eine Dezimalminute ein."); // wenn man es hier her schafft dann kann ich auch nicht mehr helfen
        }
    }
}
